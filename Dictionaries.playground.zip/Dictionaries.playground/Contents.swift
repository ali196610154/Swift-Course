


// المصفوفة تعتمد على الاندكس

var Array = ["Damascous","Kuwait","Baerout","Alryad"]
// أما القاموس يعتمد على المفتاح

var product = ["Name":"Mac Pro","Color ": "red" , "Pries":"120 Kd"]

print(product)

// وممكن أعرف القاموس بالشكل التالي
// يعني أحدد نوع المفتاح ونوع المعلومةالمطلوبة

var products : [String : String]  = ["Name":"Mac Pro","Color ": "Red" , "Pries":"120 Kd"]

// أما لو بدي نوع البيانات أي شيء رقمي أو نصي أكتب

var Products:[String:Any] = ["Name": "Mac Pro" , "Color": "Red" , "Pries": 120]

// هنا نطلب منه طباعة اللون هويبحث لو ما وجد اللون يطبع الابيض هذا معنى اشارتي الاستفهام

print(Products["Color"] ?? "Wipht")

// الان الاضافة للقاموس
Products["capacity"] = "500 GB"

print("Dictionary after Add \(products)")
// هنا إذا كان المفتاح موجود لن يتغير المفتاح ولكن سو تستبدل قيمته
//products["Color"] = "blue"

print("Dictionary after  Exiting Key \(products)")
// هناك طريقة ثانية للتعديل  وهي

Products.updateValue("Witph", forKey: "Color")

print("Dictionary after  Exiting Key \(Products)")
// الحذف في القاموس

Products.removeValue(forKey: "Color")
print("Dictionary after delet value \(Products)")

// كذلك لطباعة عدد العناصر في القاموس
print("Dictionaray count \(products.count)")


