
// هنا رح نتعرف على حلقة while   و repeat
// في حلقات الفور لوب كنا نقول مثلا
//for i in 1...5 {
//    print(i)
//}
// أما في حلقة while
//var count = 0

// while count < 6 {
 //   print(count)
//}
// إذا اردنا آن نتحقق من الشرط ثم ننفذ الامر نستخدم while
var x = 5
while x > 0 {
 //   print(x)
    x -= 1
}
// أما إذا أردنا أن نطبع القيمه الاولاى ثم نتحقق من الشرط نستخدم ال repeat
var count = 112345
repeat {
    print(count)
    count -= 1
} while  count > 0

    

