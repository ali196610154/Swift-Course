// اذا اردت التحقق من عملية منطقية

var x = 5 , y = 12

if x > y { print("x is greater than y") }  else
    
    if x == y { print("x is equal y") }  else
        
    { print("x is less than y" )
        
}

// لنفترض أنه لدين حساب شخص ونريد أن نتأكد أن حسابه محضور ولا لا

var isBloked = false

if isBloked == true  {
    print("access denied")
} else {
 print("go to Home screen")
}
// وممكن باستخدام النفي  يعني نتأكد
if !isBloked  {
   print("go to Home screen")
} else {
  print("access denied")
}
// الآن لنعرف متغييرين يعني يتحقق من شرطين أحدهما

var isDeactivated = true
if isBloked || isDeactivated {
    print("access denied")
} else {
   print("go to Home screen")
}
// ممكن نضع أكثر من عملية منطقية في الشرط
if x > 4 || x < 3  && y < 10 && y > 3 {
      print("inside if statement")
} else {
  print( "inside else statement" )
}
// باقي العملية الاخيرة
var z : Int
if x > y {
    z = x
} else {
    z = y
}
// ممكن نقوم بنفس العمل السابق بالطريقة التالية

var a = x > y  ?  x : y  //  if = ?    and   : = else
print("z = \(z)")
print("a = \(a)")
