// Array
var citise = ["Alread","Damas","Kuwait","Amman"]
print(citise[2])
//Dictionary
var userDic :[String:Any] = ["Name":"Salem","email":"mhah2246@gmail.com","city":citise[1],"balance":1200]
if let Name = userDic["Name"] {
print(Name)
}
// هنا رح نعرف التابلس وهو نوع جديد يشبه المصفوفات والقواميس ولكن الاقواس هنا هلالية يهني () ويمكن استدعاءها حسب الاندكس أو الكي حسب الطلب تابع التالي
var userTuples1 = ("Ali","Ali@ali.ali.com",citise[2],120) // هنا لاحظ أن التابلس تقبل أكثر من نوع بدون تحديد مسبق

print(userTuples1.0)// هنا لطباعة المطلوب نستخدم الاندكس ولكن بدون قوص مصفوفة بوضع نقطة بعد اسم التابلس
// الطريقة الثانية للتابلس التي تشبه القاموس ولكن بأقواس () كالتالي

var userTuples2 = (Name:"Ali",Email : "Ali@Ali.Ali.com",Citise: citise[2],balance :120) // هذه الطريقة الثانية
print(userTuples2.Citise) // هنا لطباعة المطلوب نستخدم الطريق المدونه
// الشغلة الاخيرة هي لو بدي أفرغ محتويات التابلس في متغيرات اكتب التالي
var x = userTuples2.Email
print(x)
// ولو بدي اعرف عدة متغيرات تعطي كل معطيات التابلس اكتب
//var ( Name,Email,Citise,balance) = userTuples2
//print(Name,Email,Citise,balance)
// أما اذا اردت أن اكتب بعض العناص في التعريف للمتغيرات اترك مكانها فارغ مع وجود الفاصلة مثل
var (name,Email,_,_) = userTuples1
print(name,Email)

