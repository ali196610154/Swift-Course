// Array
var citise = ["Alread","Damas","Kuwait","Amman"]
print(citise[2])
//Dictionary
var userDic :[String:Any] = ["Name":"Salem","email":"mhah2246@gmail.com","city":citise[1],"palance":1200]
if let Name = userDic["Name"] {
print(Name)
}
