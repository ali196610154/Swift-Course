import UIKit


// طرق تعريف المصفوفات واستدعادها من الاندكس

var citise = ["Damascus","Kuwait","Lybanon","syria"]
print(citise[1])


// طريقه ثانية

var countres :  [ String ] = []
print(countres)
var countre :  [ String ] = ["kuwait","Aljerya","Egybt","Turkya","Frans"]
print(countre)


// طريقة الاضافة لمصفوفة

countre.append("Damascous")
print(" Array after append \(countre)")
countre.append("Bahryn")
print(" Array after append \(countre)")
print(countre[6])


// لو أردت إضافة عدة عناصر نكتب بالشكل التالي

countre += ["Kobrs","Dalas","Alhaska"]
print(" Array after append \(countre)")

// لو أردنا اضافة عنصر في مكان محدد باستخدام الاندكس نتصرف كالتالي

countre.insert("Alsoudan", at : 2)
print(" Array after append \(countre)")

// الآن الاستبدال عنصر بدل عنصر عن طريق الامر التالي

countre [3] = "Aleppo"
print("array berfr repace \(countre)")

// الان لو أردنا حذف عنصر من المصفوفة

countre.remove(at: 4)
print("array after remove \(countre)")

// لمعرفة عدد العناصر داخل المصفوفة

print(countre.count)
