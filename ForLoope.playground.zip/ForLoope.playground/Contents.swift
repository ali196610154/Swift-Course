
// الحلقات التكرارية فور لوب
// مثلا لو بدي اطبع الارقام من ١ الى ١٠

//for i in 1...5 {
    
 //   print(i)
// }
// طيب لو بدي اطبع الارقام نفسها بشكل عكسي
var count = 10
//for i in 1...10 {
 //   print(count)
    count -= 1
    
//}
//for i in 1...10 {
//    for j in 1...10 {
   //     print("\(i) x \(j)","= \(i * j)")
//    }
//}
// لدينا نوع ثاني من حلقات الفورلوب  وهي نوعين نوع ما يحسب القيمة النهائية ونوع يحسبها كالتالي
//  وهذه تعطيك مقدار الخطوة

for i in stride(from: 1, to: 10, by: 2) {
 //   print(i)
}
// النوع الثاني
//for i in stride(from: 1, through: 10, by: 3) {
 //   print(i)
//}
//  وممكن نستخدم المصفوفات مع الفور لوب
var Array = ["ALi","Othman","Kaled","Mahmod"]
for i in 0...Array.count - 1  {
 //   print(Array[i])
}
// أو ممكن نحذف آخر نقطة ونكتب علامة < أو >
for j in 0..<Array.count {
//    print(Array[j])
}
// وممكن نكتب المصفوفة بالشكل
for one in Array {
  //  print(one)
}
// مثلا اذا بدي اطبع الاعداد الزوجية

var Array1 = [1 ,2,3,4,5,6,7,8,9,10]
for i in 0..<Array1.count {
    if Array1[i] % 2 == 0 {
   //     print("index \(i)","value \(Array1[i])")
    }
    
}
// الان مع القواميس
var Dictioary = ["Name":"Ali","Email":"Ali@Ali.Ali","city":"Hasaka"]
// الان اذا بدي أطبع كافة العناصر في القامس  اكتب
for item in Dictioary {
  //  print(item)
    // أما لطباعة القيمة فقط نكتب
 //   print("\(item.key)","\(item.value)")
}
// أيضا في طريقة أخرى للتعامل كالتالي
for (key,value) in Dictioary {
    print(key,value)
}
// ونفس الشكل بالنسبة للمصفوفة ولكن مع كلمة enumerated
for (index,value) in Array1.enumerated() {
    print(index,value)
}
