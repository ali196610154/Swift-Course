import UIKit
var x = 5 , y = 10
var z = x < y
z = x < y
z = x > y
z = x <= y
z = x >= y
x == y
x != y  // هذا معناها لا سياوي

var stMark = 60
var isPass = stMark > 49
print("isPass = \(isPass)") // هذا لطباعة النتيجة
print("IsPass = \(!isPass)") // هنا لعكس النتيجة وضع علامة التعجب


// الان نستخدم الرمز && لعملية and   و نستخدم  || بدل أو or

var isLastyear = true
var isGraduated = isLastyear && isPass   // هنا لازم الاثنين نتيجتهم true حتى تصبح النتيجة النهائية true

// أما ال or
 isLastyear = false
 isGraduated = isLastyear || isPass
// مثال يوضح أكثر
var a = true ,b = false , c = true
 print(a && b)
print(a || b)
print(a && c)
 
 
 print(a && b || c)
// ترتيب العمليات المنطقية يبدأ ب بالنفي ! أولا ثم  ال and  ثم  or
// 1- !النفي
// ٢- and
// 3- or
print(!a || (b && c))


