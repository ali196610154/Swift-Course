 // في هذا التطبيق رح نظهر للمستخدم بعض الالوان لبضع ثواني ثم نسأله عن هذه الالوان ونشوف النتيجة وسوف نستخدم if else m m  و switch
 var score = 8
 if score == 0 {
    print("very bad")
 } else  if score > 0 && score < 5 {
    print(" bad")
 } else if score > 4 && score < 8 {
    print(" good ")
 } else {
    print(" Excellent")
 }
 
 // لو بدنا نكتب نفس الكود السابق ولكن باستخدام ال  switch كالتالي
 
 
 switch score {
 case 0:   // هنا ممكن نكتب  Case 0,1  =  هنا يعني اذا كانت القيمة 0 أو 1
    print("very bad") 
 case 1..<5:
    print("bad")
 case 5..<8:
    print("good")
 default:
    print("Excellent")
 }
